from rgs_lib import run_test

def run_mini_test():
    run_test()